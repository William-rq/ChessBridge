export type Color = "w" | "b";
export type Piece =
  | "P" | "N" | "B" | "R" | "Q" | "K"
  | "p" | "n" | "b" | "r" | "q" | "k"
  | "";
export type Board = Piece[][];
export type Move = { from: [number, number], to: [number, number] };

export function initialBoard(): Board {
  return [
    ["r", "n", "b", "q", "k", "b", "n", "r"],
    ["p", "p", "p", "p", "p", "p", "p", "p"],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["P", "P", "P", "P", "P", "P", "P", "P"],
    ["R", "N", "B", "Q", "K", "B", "N", "R"],
  ];
}

export function isWhite(piece: Piece) {
  return !!piece && piece.toUpperCase() === piece;
}
export function isBlack(piece: Piece) {
  return !!piece && piece.toLowerCase() === piece;
}
export function isSameColor(p1: Piece, p2: Piece) {
  if (!p1 || !p2) return false;
  return (isWhite(p1) && isWhite(p2)) || (isBlack(p1) && isBlack(p2));
}

export function allLegalMoves(board: Board, color: Color): Move[] {
  const moves: Move[] = [];
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const piece = board[r][c];
    if (!piece) continue;
    if ((color === "w" && !isWhite(piece)) || (color === "b" && !isBlack(piece))) continue;
    moves.push(...legalMovesFor(board, r, c));
  }
  return moves;
}

export function legalMovesFor(board: Board, r: number, c: number): Move[] {
  const piece = board[r][c];
  const color = isWhite(piece) ? "w" : "b";
  const moves: Move[] = [];
  if (!piece) return moves;
  if (piece.toLowerCase() === "p") {
    const dir = color === "w" ? -1 : 1;
    if (inBounds(r + dir, c) && !board[r + dir][c]) moves.push({ from: [r, c], to: [r + dir, c] });
    if ((color === "w" && r === 6) || (color === "b" && r === 1)) {
      if (!board[r + dir][c] && !board[r + 2 * dir][c]) moves.push({ from: [r, c], to: [r + 2 * dir, c] });
    }
    for (const dc of [-1, 1]) {
      if (inBounds(r + dir, c + dc) && board[r + dir][c + dc] && !isSameColor(piece, board[r + dir][c + dc]))
        moves.push({ from: [r, c], to: [r + dir, c + dc] });
    }
  }
  if (piece.toLowerCase() === "n") {
    for (const [dr, dc] of [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]]) {
      const [nr, nc] = [r + dr, c + dc];
      if (inBounds(nr, nc) && (!board[nr][nc] || !isSameColor(piece, board[nr][nc])))
        moves.push({ from: [r, c], to: [nr, nc] });
    }
  }
  if (["b", "q"].includes(piece.toLowerCase())) {
    for (const [dr, dc] of [[-1, -1], [-1, 1], [1, -1], [1, 1]]) {
      for (let k = 1; k < 8; k++) {
        const [nr, nc] = [r + dr * k, c + dc * k];
        if (!inBounds(nr, nc)) break;
        if (!board[nr][nc]) moves.push({ from: [r, c], to: [nr, nc] });
        else {
          if (!isSameColor(piece, board[nr][nc])) moves.push({ from: [r, c], to: [nr, nc] });
          break;
        }
      }
    }
  }
  if (["r", "q"].includes(piece.toLowerCase())) {
    for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
      for (let k = 1; k < 8; k++) {
        const [nr, nc] = [r + dr * k, c + dc * k];
        if (!inBounds(nr, nc)) break;
        if (!board[nr][nc]) moves.push({ from: [r, c], to: [nr, nc] });
        else {
          if (!isSameColor(piece, board[nr][nc])) moves.push({ from: [r, c], to: [nr, nc] });
          break;
        }
      }
    }
  }
  if (piece.toLowerCase() === "k") {
    for (const dr of [-1, 0, 1]) for (const dc of [-1, 0, 1]) {
      if (dr === 0 && dc === 0) continue;
      const [nr, nc] = [r + dr, c + dc];
      if (inBounds(nr, nc) && (!board[nr][nc] || !isSameColor(piece, board[nr][nc])))
        moves.push({ from: [r, c], to: [nr, nc] });
    }
  }
  return moves;
}

function inBounds(r: number, c: number) {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}

export function makeMove(board: Board, move: Move): Board {
  const newBoard: Board = board.map(row => row.slice());
  const [fr, fc] = move.from;
  const [tr, tc] = move.to;
  newBoard[tr][tc] = newBoard[fr][fc];
  newBoard[fr][fc] = "";
  return newBoard;
}

export function boardToFen(board: Board, turn: Color): string {
  let fen = "";
  for (let r = 0; r < 8; r++) {
    let empty = 0;
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) empty++;
      else {
        if (empty) fen += empty;
        empty = 0;
        fen += p;
      }
    }
    if (empty) fen += empty;
    if (r < 7) fen += "/";
  }
  fen += ` ${turn} - - 0 1`;
  return fen;
}

export function fenToBoard(fen: string): { board: Board, turn: Color } {
  const [rows, turn] = fen.split(" ");
  const board: Board = [];
  rows.split("/").forEach(row => {
    const r: Piece[] = [];
    for (const ch of row) {
      if (ch >= "1" && ch <= "8") {
        for (let i = 0; i < parseInt(ch); i++) r.push("");
      } else {
        r.push(ch as Piece);
      }
    }
    board.push(r);
  });
  return { board, turn: (turn as Color) };
}